CREATE PROCEDURE `test3`(IN `arg1` VARCHAR(45), IN `arg2` VARCHAR(45), IN `arg3` INT(11), OUT `rez` INT(11))
  BEGIN
    INSERT into tab1(id,name,surname,gender,age) VALUES (arg3,arg1,arg2,'F',18);
    SELECT arg3 into rez;
END